# SnowBoard Localisation
![SnowBoard Icon](https://i.imgur.com/du1jZL7.png)

Let's localise SnowBoard!
Simply submit a pull request or contact SparkDev on Discord or [Twitter][ST].

# Contributions

## Brazilian Portuguese
### natobr
Twitter: 
Discord: nato#1990

## Chinese
### JJ
Twitter: [@JJGadgets][JJT]

Discord: JJGadgets#1337

### maaya1989
Twitter:

Discord:

### Acreson
Twitter: 

Discord:

### sutuplus
Twitter: [HiCarby](https://twitter.com/HiCarby)

Discord: redmine_cat#9293

## Danish
### YaYPIXXO
Twitter: [@Ra1nPix](https://twitter.com/Ra1nPix)

Discord: yaypixxo#6969

GitHub: [viggou](https://github.com/viggou)

## French
### relisiuol
Twitter: [relisiuol](https://twitter.com/relisiuol)

GitHub: [relisiuol](https://github.com/relisiuol)

## German
### Emy
Twitter:

Discord: Emy#0001

## Russian
### gkeep
GitHub: [gkeep](https://github.com/gkeep)

Discord: gkeep#2332

## Turkish
### Mustafa
Twitter: [@MustyAslan99](https://twitter.com/MustyAslan99)

## Korean
### BawAppie
Twitter: [@BawAppie](https://tiwtter.com/BawAppie)


## Italian
### bart172
Twitter:

Discord

## French
### relisiuol
Twitter: 

Discord:

## Persian
### behradjafari1
Twitter: 

Discord:

## Arabic
### iA7myd
Twitter: 

Discord:

## Czech
### Toooorch
Twitter: 

Discord:

## Bangla (Bangladesh)
### atifchy
Twitter: [@atifchy_](https://twitter.com/atifchy_)

Discord: Atif#3278

## Spanish (Latin American)
### PONCE54958
Twitter: [PONCE54958](https://twitter.com/PONCE54958)

Discord:

## Japanese
### eve0415
Twitter: [eve0415](https://twitter.com/eveevekun)

Discord: eve0415#3603

## Lithuanian
### nj0rr
Twitter: [ni0rr](https://twitter.com/ni0rr)

Discord: nj0rr#5645

[ST]: https://twitter.com/SparkDev_ "Spark's Twitter"
[JJT]: https://twitter.com/JJGadgets "JJ's Twitter"
[PONCE54958]: https://twitter.com/PONCE54958 "PONCE54958's Twitter"
[eve0415]: https://twitter.com/eve0415 "eve0415's Twitter"
[HiCarby]: https://twitter.com/HiCarby "HiCarby's Twitter"
[ni0rr]: https://twitter.com/ni0rr "ni0rr's Twitter"
